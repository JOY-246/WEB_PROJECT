<?php
session_start();

// ✅ Mock peon email session
$_SESSION['peon_email'] = $_SESSION['peon_email'] ?? 'delivery@company.com';
$peon_email = $_SESSION['peon_email'];

// ✅ Mock data for orders (replace with DB queries in real use)
$orders = [
    ['id'=>1, 'product_name'=>'Laptop Dell XPS 13','quantity'=>2,'staff_name'=>'John Smith','status'=>'Confirmed'],
    ['id'=>2, 'product_name'=>'iPhone 15 Pro','quantity'=>1,'staff_name'=>'Sarah Johnson','status'=>'Confirmed'],
    ['id'=>3, 'product_name'=>'Samsung Monitor 27"','quantity'=>3,'staff_name'=>'Mike Davis','status'=>'Confirmed'],
    ['id'=>4, 'product_name'=>'Wireless Keyboard','quantity'=>5,'staff_name'=>'Emily Brown','status'=>'Pending'],
    ['id'=>5, 'product_name'=>'USB-C Cable','quantity'=>10,'staff_name'=>'David Wilson','status'=>'Confirmed'],
    ['id'=>6, 'product_name'=>'Bluetooth Headphones','quantity'=>2,'staff_name'=>'Lisa Garcia','status'=>'Cancelled'],
    ['id'=>7, 'product_name'=>'Tablet iPad Air','quantity'=>1,'staff_name'=>'Tom Anderson','status'=>'Confirmed'],
    ['id'=>8, 'product_name'=>'Printer Canon','quantity'=>1,'staff_name'=>'Anna Taylor','status'=>'Pending'],
];

// ✅ Count orders for dashboard summary
$total_orders = count($orders);
$pending_count = count(array_filter($orders, fn($o)=>$o['status']=='Pending'));
$confirmed_count = count(array_filter($orders, fn($o)=>$o['status']=='Confirmed'));
$cancelled_count = count(array_filter($orders, fn($o)=>$o['status']=='Cancelled'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Peon Dashboard</title>
<link rel="stylesheet" href="IRMS_Peon_order.css">
</head>
<body>

<header>
    <div class="header-left">
        <span class="logo">🚚 Peon Dashboard</span>
    </div>
    <div class="header-right">
        <span>Welcome, <b><?php echo $peon_email; ?></b></span>
        <a href="logout.php" class="btn logout">Logout</a>
    </div>
</header>

<section class="dashboard-summary">
    <div class="summary-card">
        <div class="title">📦 Total Orders</div>
        <div class="value"><?php echo $total_orders; ?></div>
    </div>
    <div class="summary-card">
        <div class="title">⏳ Pending</div>
        <div class="value"><?php echo $pending_count; ?></div>
    </div>
    <div class="summary-card">
        <div class="title">✅ Confirmed</div>
        <div class="value"><?php echo $confirmed_count; ?></div>
    </div>
    <div class="summary-card">
        <div class="title">❌ Cancelled</div>
        <div class="value"><?php echo $cancelled_count; ?></div>
    </div>
</section>

<section class="orders-section">
    <div class="orders-header">
        <input type="text" placeholder="Search orders...">
        <select>
            <option>All Status</option>
            <option>Pending</option>
            <option>Confirmed</option>
            <option>Cancelled</option>
        </select>
        <button class="btn refresh">Refresh</button>
    </div>

    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Ordered By</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($orders as $o): ?>
            <tr>
                <td>#<?php echo $o['id']; ?></td>
                <td><?php echo htmlspecialchars($o['product_name']); ?></td>
                <td><?php echo $o['quantity']; ?></td>
                <td><?php echo htmlspecialchars($o['staff_name']); ?></td>
                <td class="status <?php echo strtolower($o['status']); ?>"><?php echo strtoupper($o['status']); ?></td>
                <td>
                    <?php if($o['status'] === 'Pending'): ?>
                        <button class="btn confirm">✔ CONFIRM</button>
                        <button class="btn cancel">✖ CANCEL</button>
                    <?php else: ?>
                        <span class="status <?php echo strtolower($o['status']); ?>"><?php echo strtoupper($o['status']); ?></span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>

</body>
</html>
