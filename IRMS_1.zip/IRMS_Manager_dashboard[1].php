<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>IRMS - Manager Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      margin: 0;
      height: 100vh;
      background: linear-gradient(135deg, #1a2530, #2c3e50);
      display: flex;
      flex-direction: column;
    }

    /* Header */
    .header {
      background: rgba(0,0,0,0.8);
      color: white;
      padding: 25px;
      text-align: center;
      position: relative;
    }
    .header h1 {
      margin: 0;
      font-size: 42px;
      font-weight: bold;
      letter-spacing: 2px;
    }
    .header h1 span { color: #f1c40f; }
    
    /* Navigation buttons */
    .nav-buttons {
      position: absolute;
      width: 100%;
      top: 50%;
      transform: translateY(-50%);
      display: flex;
      justify-content: space-between;
      padding: 0 20px;
      box-sizing: border-box;
    }
    .nav-btn {
      background: #f1c40f;
      padding: 12px 25px;
      border-radius: 30px;
      color: black;
      text-decoration: none;
      font-weight: bold;
      transition: 0.3s;
    }
    .nav-btn:hover { 
      background: #d4ac0d; 
      transform: scale(1.05);
    }

    /* Main Content */
    .container {
      flex: 1;
      display: flex;
      padding: 20px;
    }

    /* Left Sidebar */
    .sidebar {
      width: 250px;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 10px;
      padding: 20px;
      margin-right: 20px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    }
    .sidebar-option {
      padding: 15px;
      margin: 10px 0;
      background: #3498db;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      transition: 0.3s;
      font-weight: bold;
    }
    .sidebar-option:hover, .sidebar-option.active {
      background: #2980b9;
      transform: translateX(5px);
    }

    /* Main Content Area */
    .main-content {
      flex: 1;
      background: rgba(255, 255, 255, 0.9);
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.2);
      display: flex;
      flex-direction: column;
    }
    .content-header {
      font-size: 24px;
      font-weight: bold;
      color: #2c3e50;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid #3498db;
    }
    .salary-details {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .salary-item {
      display: flex;
      justify-content: space-between;
      padding: 12px;
      border-bottom: 1px solid #eee;
    }
    .salary-item:last-child {
      border-bottom: none;
    }
    .salary-value {
      font-weight: bold;
      color: #27ae60;
    }
    .salary-item.total {
      background: #ecf0f1;
      font-weight: bold;
    }

    /* Footer */
    .footer {
      background: rgba(0,0,0,0.85);
      color: white;
      text-align: center;
      padding: 15px;
      font-size: 14px;
    }

    /* Responsive adjustments */
    @media screen and (max-width: 768px) {
      .container {
        flex-direction: column;
      }
      .sidebar {
        width: 100%;
        margin-right: 0;
        margin-bottom: 20px;
      }
    }
  </style>
</head>
<body>

<!-- Header -->
<div class="header">
  <div class="nav-buttons">
    <a href="IRMS_Access_system.php" class="nav-btn"><i class="fas fa-arrow-left"></i> Back</a>
    <a href="#" class="nav-btn">Next <i class="fas fa-arrow-right"></i></a>
  </div>
  <h1>IR<span>MS</span> Manager Dashboard</h1>
</div>

<!-- Main Content -->
<div class="container">
  <!-- Left Sidebar -->
  <div class="sidebar">
    <div class="sidebar-option active" data-target="applicants">
      <i class="fas fa-users"></i> Applicants
    </div>
    <div class="sidebar-option" data-target="active-persons">
      <i class="fas fa-user-check"></i> Active Persons
    </div>
    <div class="sidebar-option" data-target="salary">
      <i class="fas fa-money-bill-wave"></i> Salary
    </div>
    <div class="sidebar-option" data-target="product-management">
      <i class="fas fa-boxes"></i> Product Management
    </div>
  </div>

  <!-- Main Content Area -->
  <div class="main-content">
    <div class="content-header">
      <i class="fas fa-money-bill-wave"></i> Salary Information
    </div>
    
    <div class="salary-details">
      <div class="salary-item">
        <span>Applicants Processing Cost</span>
        <span class="salary-value">$4,500.00</span>
      </div>
      <div class="salary-item">
        <span>Active Personnel Salaries</span>
        <span class="salary-value">$28,750.00</span>
      </div>
      <div class="salary-item">
        <span>Management Team Compensation</span>
        <span class="salary-value">$15,300.00</span>
      </div>
      <div class="salary-item total">
        <span>Total Monthly Salary Expenditure</span>
        <span class="salary-value">$48,550.00</span>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->
<div class="footer">
  <p>&copy; 2025 Inventory Requisition & Management System</p>
</div>

<script>
  // Handle sidebar option clicks
  document.querySelectorAll('.sidebar-option').forEach(option => {
    option.addEventListener('click', function() {
      document.querySelectorAll('.sidebar-option').forEach(opt => opt.classList.remove('active'));
      this.classList.add('active');
      updateContent(this.getAttribute('data-target'));
    });
  });

  function updateContent(target) {
    const contentHeader = document.querySelector('.content-header');
    const contentBody = document.querySelector('.salary-details');

    switch(target) {
      case 'applicants':
        contentHeader.innerHTML = '<i class="fas fa-users"></i> Applicants Information';
        contentBody.innerHTML = `
          <div class="salary-item"><span>New Applications This Month</span><span class="salary-value">24</span></div>
          <div class="salary-item"><span>Applications in Review</span><span class="salary-value">12</span></div>
          <div class="salary-item"><span>Applications Approved</span><span class="salary-value">8</span></div>
          <div class="salary-item"><span>Applications Rejected</span><span class="salary-value">4</span></div>
        `;
        break;

      case 'active-persons':
        contentHeader.innerHTML = '<i class="fas fa-user-check"></i> Active Personnel';
        const teamMembers = 5;
        const deliveryMen = 8;
        const total = teamMembers + deliveryMen;
        contentBody.innerHTML = `
          <div class="salary-item"><span><i class="fas fa-user-friends"></i> Active Team Members</span><span class="salary-value">${teamMembers}</span></div>
          <div class="salary-item"><span><i class="fas fa-truck"></i> Active Delivery Men</span><span class="salary-value">${deliveryMen}</span></div>
          <div class="salary-item total"><span>Total Active Staff</span><span class="salary-value">${total}</span></div>
        `;
        break;

      case 'salary':
        contentHeader.innerHTML = '<i class="fas fa-money-bill-wave"></i> Salary Information';
        contentBody.innerHTML = `
          <div class="salary-item"><span>Applicants Processing Cost</span><span class="salary-value">$4,500.00</span></div>
          <div class="salary-item"><span>Active Personnel Salaries</span><span class="salary-value">$28,750.00</span></div>
          <div class="salary-item"><span>Management Team Compensation</span><span class="salary-value">$15,300.00</span></div>
          <div class="salary-item total"><span>Total Monthly Salary Expenditure</span><span class="salary-value">$48,550.00</span></div>
        `;
        break;

      case 'product-management':
        contentHeader.innerHTML = '<i class="fas fa-boxes"></i> Product Management';
        contentBody.innerHTML = `
          <div class="salary-item"><span><i class="fas fa-chair"></i> Chair</span><span class="salary-value">25</span></div>
          <div class="salary-item"><span><i class="fas fa-table"></i> Table</span><span class="salary-value">15</span></div>
          <div class="salary-item"><span><i class="fas fa-desktop"></i> Computer</span><span class="salary-value">40</span></div>
          <div class="salary-item"><span><i class="fas fa-shopping-basket"></i> Basket</span><span class="salary-value">30</span></div>
          <div class="salary-item"><span><i class="fas fa-snowflake"></i> AC</span><span class="salary-value">10</span></div>
          <div class="salary-item"><span><i class="fas fa-fan"></i> Fan</span><span class="salary-value">20</span></div>
          <div class="salary-item"><span><i class="fas fa-lightbulb"></i> Tube Light</span><span class="salary-value">50</span></div>
          <div class="salary-item"><span><i class="fas fa-coffee"></i> Coffee</span><span class="salary-value">100</span></div>
          <div class="salary-item"><span><i class="fas fa-file-alt"></i> Paper</span><span class="salary-value">200</span></div>
          <div class="salary-item"><span><i class="fas fa-pen"></i> Pen</span><span class="salary-value">300</span></div>
          <div class="salary-item" id="more-products"><span><i class="fas fa-plus"></i> More</span><span class="salary-value"></span></div>
        `;

        // Add click event to More button
        document.getElementById('more-products').addEventListener('click', function() {
          const newProduct = prompt('Enter new product name:');
          if(newProduct) {
            const div = document.createElement('div');
            div.classList.add('salary-item');
            div.innerHTML = `<span><i class="fas fa-box"></i> ${newProduct}</span><span class="salary-value">0</span>`;
            this.before(div);
          }
        });
        break;
    }
  }
</script>

</body>
</html>
